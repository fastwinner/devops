package ci.inphb;

public class Calculator {
    public long add(int a, int b) {
        return a + b;
    }
}
