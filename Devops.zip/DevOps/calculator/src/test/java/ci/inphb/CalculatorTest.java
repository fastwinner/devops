package ci.inphb;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CalculatorTest {
    @Test
    public void addTwoAndFive_ShouldReturn_Seven() {
        // Given
        int a = 2;
        int b = 5;
        Calculator calculator = new Calculator();

        // When
        long result = calculator.add(a, b);

        // Then
        assertEquals(7, result);
    }
}
