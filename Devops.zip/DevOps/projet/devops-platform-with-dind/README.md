# Projet de fin de formation : Mise en Place d'un Environnement DevOps avec Docker-in-Docker

## Contexte

Vous êtes recruté en tant qu'ingénieur DevOps pour concevoir et déployer un environnement complet permettant à une équipe de développement et d'opérations d'automatiser leurs processus, surveiller leurs systèmes, et gérer leurs conteneurs de manière centralisée. Cet environnement doit être entièrement conteneurisé et basé sur des technologies modernes alignées sur les pratiques DevOps.

## Objectif

Créer un environnement DevOps complet constitué de plusieurs serveurs conteneurisés basés sur Docker-in-Docker (DinD). Chaque serveur héberge des outils spécifiques nécessaires pour un pipeline DevOps complet.

## Description du Projet

Vous allez mettre en place un ensemble de conteneurs représentant différents serveurs fonctionnels. Chaque serveur sera configuré pour exécuter un ensemble d’outils ou de services DevOps.

Voici les serveurs à déployer :
- **Un load balancer** avec **Nginx** pour la répartition de la charge et la gestion des requêtes vers les applications
- **Un serveur CI/CD** utilisant **Jenkins** pour l'automatisation des builds et des déploiements, ainsi que **SonarQube** pour l'analyse de la qualité du code.
- **Un serveur de monitoring** basé sur **Prometheus** et **Grafana** pour la collecte et la visualisation des métriques.
- **Un serveur de base de données** avec **MariaDB** pour les bases relationnelles et **Redis** pour la gestion des caches des applications.
- **Un serveur d'applications** conteneurisé, hébergeant plusieurs applications de démonstration.

### Spécifications des serveurs
| Serveur         | Nom du serveur       | Image de base | Ports                                                    |
|-----------------|----------------------|---------------|----------------------------------------------------------|
| Load balancer   | load-balancer-server | stic/dind     | Nginx: 80                                                |
| CI/CD           | cicd-server          | stic/dind     | Jenkins: 8080; SonarQube: 9000                           |
| Monitoring      | monitoring-server    | stic/dind     | Prometheus: 9090; Grafana: 3000                          |
| Base de données | database-server      | stic/dind     | MariaDB: 3306; Redis: 6379                               |
| Applications    | application-server   | stic/dind     | static-website-example : 8000; simple-webapp-color: 5000 |

### Spécifications des conteneurs
| Conteneur              | Image de base                                                                 |
|------------------------|-------------------------------------------------------------------------------|
| Nginx                  | nginx:alpine                                                                  |                                                                 |
| Jenkins                | Créer une image à partir du Dockerfile se trouvant dans le répertoire jenkins |
| SonarQube              | sonarqube:lts-community                                                       |
| Prometheus             | prom/prometheus:v2.53.1                                                       |
| Grafana                | grafana/grafana                                                               |
| MariaDB                | mariadb:11.4.3                                                                |
| Redis                  | redis:7-alpine                                                                |
| static-website-example | Conteneurisé l'application **static-website-example**                         |
| simple-webapp-color    | Conteneurisé l'application **simple-webapp-color**                            |

Ci-dessous les liens des applications :
- [static-website-example](https://github.com/jfyoboue/static-website-example.git)
- [simple-webapp-color](https://github.com/jfyoboue/simple-webapp-color.git)

## Prérequis
Il faut un serveur avec Docker installé dessus pour réaliser ce projet. Si nécessaire; un script d'installation de Docker sur un serveur Ubuntu est disponible dans le repertoire **docker**

## Instructions

### Clonage du projet
Cloner le projet [devops-platform-with-dind](https://gitlab.com/jfyoboue/devops-platform-with-dind.git)

### Concept de *Docker-in-Docker (DinD)* 
L'idée principale est de permettre à un conteneur Docker d'exécuter d'autres conteneurs Docker. 
Ce concept est appelé **Docker-in-Docker (DinD)**. Voici comment mettre cela en place :

#### 1. Créer un Dockerfile pour le serveur Docker
Le Dockerfile se trouve dans le repertoire **dind**

#### 2. Construire l'image Docker
Exécutez la commande suivante dans le répertoire contenant le Dockerfile :
```shell script
docker build -t stic/dind .
```

#### 3. Exécuter le conteneur DinD
Lorsque vous exécutez ce conteneur, vous devez activer les privilèges pour qu'il puisse gérer d'autres conteneurs.
```shell script
docker run --privileged -d --name app-server-docker -p 2375:2375 stic/dind
```

- *--privileged* : Nécessaire pour permettre au conteneur d'accéder au démon Docker.
- *-p 2375:2375* : Expose le démon Docker pour que d'autres applications puissent interagir avec lui.

#### 4. Utilisation du serveur Docker
Une fois le conteneur en cours d'exécution, vous pouvez exécuter d'autres conteneurs Docker en vous connectant à ce conteneur.

Exemple :
```shell script
docker exec -it app-server-docker sh
docker run -d nginx
```

#### 5. Création d'un serveur avec Docker Compose
```yaml
services:
  dind-server:
    image: stic/dind
    container_name: app-server-docker
    privileged: true # Nécessaire pour exécuter Docker dans un conteneur
    ports:
      - "2375:2375" # Expose le démon Docker pour interagir avec lui
    volumes:
      - dind-data:/var/lib/docker # Persistance des données Docker
    environment:
      DOCKER_TLS_CERTDIR: "" # Désactive TLS pour simplifier l'accès local

volumes:
  dind-data:
    driver: local
```

### Création du serveur *load-balancer-server* avec DinD
1. Créez un répertoire **load-balancer-server**
2. A l'intérieur de ce repertoire, créez un fichier **entrypoint.sh** avec le contenu ci-dessus:
```shell script
#!/bin/bash

# Assurez-vous que Docker est lancé
dockerd &

# Attendre que le démon Docker soit prêt
while ! docker info > /dev/null 2>&1; do
    echo "Attente du démarrage de Docker..."
    sleep 1
done

# Aller dans le dossier où se trouve compose.yml
cd /app

# Lancer docker-compose
docker compose up
```
3. Toujours à l'intérieur de ce répertoire, créez un fichier **compose.yml** contenant un conteneur **Nginx**
4. Toujours à l'intérieur de ce répertoire, créez un fichier **Dockerfile** avec le contenu ci-dessous
```dockerfile
# Étape de base avec DinD
FROM stic/dind

# Copier le fichier compose.yml dans l'image
COPY compose.yml /app/compose.yml

# Ajouter un script d'entrée
COPY entrypoint.sh /entrypoint.sh
RUN chmod +x /entrypoint.sh

# Définir le point d'entrée
ENTRYPOINT ["/entrypoint.sh"]
```

Vous pouvez à présent construire un conteneur à partir du Dockerfile

### Création des autres serveurs
En suivant le même procédé que lors de la création du serveur de load balancer; créez les autres serveurs à savoir :
- cicd-server
- monitoring-server
- database-server
- application-server

### Création de l'infrastructure
Créez un fichier **compose.yml** global permettant de lancer l'ensemble des serveurs en une seule commande.


## Livrables attendus
Les fichiers pour les différents serveurs :
- load-balancer-server
- cicd-server
- monitoring-server
- database-server
- application-server

Le fichier **compose.yml** global.
Un fichier **Architecture.md** décrivant l'architecture de la solution.
Un fichier **Member.md** contenant les membres du groupe.

Créez un projet **GitLab** sur lequel vous allez publier votre projet.



